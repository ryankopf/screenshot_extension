# Screenshot Extension

This browser extension lets you send a screenshot to our server of completed work.

Just price Control + Shift + K to send a screenshot.

Make sure to set your Name in the settings!
